curl -X GET \
  -H 'Content-Type: application/json' \
  -H 'X-Auth-Token: PASTE-TOKEN-HERE' \
  https://sandboxdnac.cisco.com/dna/intent/api/v1/network-device/

# Module 2: Learning the Foundations of Software Design
There are two main exercise topics. First, `observer.py` illustrates the
Observer design pattern discussed in the clips. Second, the `mvc/`
directory contains all the files used to build the CRM application.
This follows the Model View Controller (MVC) design pattern.
